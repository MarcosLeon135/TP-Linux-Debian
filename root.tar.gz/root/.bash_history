history
history -w
rm -f /root/.bash_history
journalctl --rotate
journalctl --vacuum-time=1s
apt clean
sync
poweroff
hostnamectl set-hostname TPServer
nano /etc/hostname
vim /etc/hostname
vim /etc/hosts
cat /etc/debian_version
apt update
vim /etc/apt/sources.list
apt update
apt full-upgrade
reboot
apt update
apt install apache2 
apt cache-search php
apt search php
apt install php
apt install libapache2-mod-php
systemctl status apache2
ls -l
pwd
ls -l
cd -
ls -l
cd Material_Adicional_TPVMCA/
ls -l
cp /root/index,php /var/www/html/
cp /root/index.php /var/www/html/
cp /root/Material_Adicional_TPVMCA/index.php /var/www/html/
cd -
ls /var/www/html
cp /root/Material_Adicional_TPVMCA/logo.png /var/www/html/
ls -l /var/www/html
ip a
rm /var/www/html/index.html
ls -l /var/www/html
systemctl restart apache2
ip a
systemctl status apache2
ls -l /var/www/html
cat /var/www/html/index.php
ip a
reboot
ip a
systemctl status apache2
ip a
ls -l /var/www/html/index.php
ls -l /var/www/html/
php /var/www/html/index.php
apt cache search mysql
apt search mysql
apt install mariadb-server
php /var/www/html/index.php
apt-cache search mysql
apt install php-mysql 
php /var/www/html/index.php
systemctl restart apache2
php /var/www/html/index.php
mariadb
mariadb
ls -l
cd Material_Adicional_TPVMCA/
ls -l
loadkeys us
cd -
loadkeys us
mariadb « /root/Material_Adicional_TPVMCA/db.sql
apt install kbd
loadkeys us
dpkg-reconfigure keyboard-configuration
loadkeys us
reboot
lbslk
lsblk
fdisk -l
fdisk /dev/sdc
mkfs -t ext4 /dev/sdc1
mkfs -t ext4 /dev/sdc2
mkdir /www_dir
mkdir /backup_dir
mount /dev/sdc1 /www_dir
mount /dev/sdc2 /backup_dir/
df -h
mv /var/www/html/index.php /www_dir/
ls /www_dir
mv /var/www/html/logo.png /www_dir/
ls /var/www/html
vim /etc/apache2/sites-available/000-default.conf 
vim /etc/apache2/apache2.conf
systemctl restart apache2
blkid
vim /etc/fstab
mount -a
df -h
cat /proc/partitions > /opt/particion
cat /opt/particion
exit
lsblk
cat /etc/fstab
ls /www_dir
ls /backup_dir
ls /etc/apache2
systemctl status apache2
systemctl status mariadb
blkid
vim /etc/fstab
mount -a
systemctl daemon-reload
mount | grep backup_dir
reboot
lsblk
cat /etc/fstab 
vim /etc/fstab 
cat /etc/fstab 
mount -a
systemctl daemon-reload
mount -a
findmnt 
reboot
lsblk
systemctl status apache2
systemctl status mariadb
df -h
history
less history
history | less
history | less
systemctl status ssh
history | less
ls -la /root/.ssh
cat /root/.ssh/authorized_keys 
grep PermitRootLogin /etc/ssh/sshd_config
history | grep ssh
exit
cat etc/apt/sources.list
cat etc/apt/sources.list
cat /etc/apt/sources.list
cd /opt/scripts
cd /opt
ls -l
mkdir scripts
ls -l
cd scripts
vim backup_full.sh
