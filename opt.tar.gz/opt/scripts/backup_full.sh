#!/bin/bash

ORIGEN=$1
DESTINO=$2
FECHA=$(date +%Y%m%d)
if [ "$1" = "-help" ];then
	echo "Uso:"
	echo ",/backup_full.sh ORIGEN DESTINO"
	echo "Ejemplo:"
	echo "./backup_full.sh /www_dir /backup_dir"
else
	if [ -d "$1" ];then
		echo "El directorio de origen existe"
		
		if [ -d "$2" ];then
			echo "El directorio de destino existe"
		
			if [ "$1" = "/var/log" ];then
				FILE=log_bkp_${FECHA}.tar.gz
			fi
			
			if [ "$1" = "/www_dir" ];then
				FILE=www_dir_bkp_${FECHA}.tar.gz
			fi

			tar -cvzf $DESTINO/$FILE $ORIGEN
			
			echo "Backup realizado"
			
		else
			echo "El directorio de destino no existe"

		fi
	else
		echo "El directorio de origen no existe"
	fi
fi
